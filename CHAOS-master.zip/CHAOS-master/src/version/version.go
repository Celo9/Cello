package version

func GetVersion() string {
	return "3.0"
}
